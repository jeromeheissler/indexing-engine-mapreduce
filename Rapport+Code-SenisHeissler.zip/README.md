indexing-engine-mapreduce
=========================

The aim of this project is to take control of Hadoop and its implementation of MapReduce.
This project implement a textual comparison that is based on the cosine similarity measure